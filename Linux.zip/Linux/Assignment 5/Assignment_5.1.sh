#!/bin/bash
# Check if at least two arguments are provided
if [ "$#" -lt 2 ]; then
    echo "Usage: $0 <template file> key1=value1 key2=value2 ..."
    exit 1
fi
# Read the template file
template_file=$1
if [ ! -f "$template_file" ]; then
    echo "Template file not found!"
    exit 1
fi
# Load the template content
template=$(<"$template_file")
# Loop through key-value pairs and perform replacements
for arg in "${@:2}"; do
    IFS='=' read -r key value <<< "$arg"
    template="${template//\{\{$key\}\}/$value}"
done
# Output the final processed template
echo "$template"
#!/bin/bash

# Function to add a line at the top of the file
addLineTop() {
  sed -i "1i$line" "$file"
}

# Function to add a line at the bottom of the file
addLineBottom() {
  echo "$line" >> "$file"
}

# Function to add a line at a specific line number
addLineAt() {
  sed -i "${lineno}i$line" "$file"
}

# Function to update the first word at the first line
updateFirstWordAtLine() {
  sed -i "0,/$old_word/s//$new_word/" "$file"
}

# Function to replace all occurrences of a word in the file
updateAllWords() {
  sed -i "s/$old_word/$new_word/g" "$file"
}

# Function to insert a word before and after a specific word
insertWord() {
  sed -i "s/\($word1\)/$new_word \1/g" "$file"   # Insert before word1
  sed -i "s/\($word2\)/\1 $new_word/g" "$file"   # Insert after word2
}

# Function to delete a specific line by its number
deleteLine() {
  sed -i "${lineno}d" "$file"
}

# Function to delete a line containing a specific word
deleteLineContaining() {
  sed -i "/$word/d" "$file"
}

# Additional feature: Find and count occurrences of a word
findWord() {
  grep -n -o "$word" "$file" | wc -l
}

# Additional feature: Append text to a specific line
appendLine() {
  sed -i "${lineno}s/$/ $text/" "$file"
}

# Additional feature: Replace a specific line with new content
replaceLine() {
  sed -i "${lineno}s/.*/$new_content/" "$file"
}

# Additional feature: Display lines within a specified range
displayLines() {
  sed -n "${start},${end}p" "$file"
}

# Main script logic to handle command-line arguments
case "$1" in
  addLineTop)
    file="$2"
    line="$3"
    addLineTop
    ;;
  addLineBottom)
    file="$2"
    line="$3"
    addLineBottom
    ;;
  addLineAt)
    file="$2"
    lineno="$3"
    line="$4"
    addLineAt
    ;;
  updateFirstWordAtLine)
    file="$2"
    old_word="$3"
    new_word="$4"
    updateFirstWordAtLine
    ;;
  updateAllWords)
    file="$2"
    old_word="$3"
    new_word="$4"
    updateAllWords
    ;;
  insertWord)
    file="$2"
    word1="$3"
    word2="$4"
    new_word="$5"
    insertWord
    ;;
  deleteLine)
    file="$2"
    lineno="$3"
    deleteLine
    ;;
  deleteLineContaining)
    file="$2"
    word="$3"
    deleteLineContaining
    ;;
  findWord)
    file="$2"
    word="$3"
    findWord
    ;;
  appendLine)
    file="$2"
    lineno="$3"
    text="$4"
    appendLine
    ;;
  replaceLine)
    file="$2"
    lineno="$3"
    new_content="$4"
    replaceLine
    ;;
  displayLines)
    file="$2"
    start="$3"
    end="$4"
    displayLines
    ;;
  *)
    echo "Invalid command"    ;;
    esac
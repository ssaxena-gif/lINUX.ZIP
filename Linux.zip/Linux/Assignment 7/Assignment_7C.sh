#!/bin/bash

# Function to create a tag
create_tag() {
    tag_name=$1
    if git tag | grep -q "^$tag_name$"; then
        echo "Tag '$tag_name' already exists."
    else
        git tag "$tag_name"
        echo "Tag '$tag_name' created."
    fi
}

# Function to list all tags
list_tags() {
    tags=$(git tag)
    if [ -z "$tags" ]; then
        echo "No tags available."
    else
        echo "$tags"
    fi
}

# Function to delete a tag
delete_tag() {
    tag_name=$1
    if git tag | grep -q "^$tag_name$"; then
        git tag -d "$tag_name"
        echo "Tag '$tag_name' deleted."
    else
        echo "Tag '$tag_name' not found."
    fi
}

# Main logic to parse command-line arguments
while getopts "t:ld:" opt; do
    case $opt in
        t) create_tag "$OPTARG" ;;  # Create a tag with the given name
        l) list_tags ;;             # List all tags
        d) delete_tag "$OPTARG" ;;  # Delete the tag with the given name
        *) echo "Usage: $0 -t <tag_name> | -l | -d <tag_name>" ;;
    esac
done

# If no argument is provided, show usage
if [ $# -eq 0 ]; then
    echo "Usage: $0 -t <tag_name> | -l | -d <tag_name>"
fi
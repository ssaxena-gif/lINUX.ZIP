#!/bin/bash

generate_report() {
    local repo_url=$1
    local days=$2
    local repo_name=$(basename -s .git "$repo_url")

    # Clone the repository if it doesn't exist
    [ ! -d "$repo_name" ] && git clone "$repo_url"
    cd "$repo_name" || exit

    local report_file="${repo_name}_commit_report.csv"
    echo "Commit ID,Author Name,Author Email,Commit Message,Changed Files" > "$report_file"

    # Get commits in the specified date range
    git log --since="$days days ago" --pretty=format:'%H|%an|%ae|%s' | while IFS='|' read -r commit_id author_name author_email commit_message; do
        changed_files=$(git diff-tree --no-commit-id --name-only -r "$commit_id" | tr '\n' ', ')
        echo "$commit_id,$author_name,$author_email,$commit_message,\"$changed_files\"" >> "$report_file"
    done

    echo "CSV report generated: $report_file"
}

# Main execution
read -p "Enter the repository URL: " repo_url
read -p "Enter the number of days for the report: " days

generate_report "$repo_url" "$days"
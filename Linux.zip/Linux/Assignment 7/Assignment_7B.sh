#!/bin/bash

# Function to list all branches
list_branches() {
  echo "Available Branches:"
  git branch
}

# Function to create a new branch
create_branch() {
  if [ -z "$1" ]; then
    echo "Please provide the branch name."
    exit 1
  fi
  git branch "$1"
  echo "Branch '$1' created."
}

# Function to delete a branch
delete_branch() {
  if [ -z "$1" ]; then
    echo "Please provide the branch name."
    exit 1
  fi
  git branch -d "$1"
  echo "Branch '$1' has been deleted."
}

# Function to merge branches
merge_branches() {
  if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Please provide both source and target branches for merging."
    exit 1
  fi
  git checkout "$2" || { echo "Failed to switch to branch '$2'."; exit 1; }
  git merge --no-ff "$1" || {
    echo "Merge conflicts detected. Please resolve them and retry."
    git checkout -
    exit 1
  }
  echo "Branch '$1' successfully merged into '$2'."
}

# Function to rebase branches
rebase_branches() {
  if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Please provide both base and target branches for rebasing."
    exit 1
  fi
  git checkout "$2" || { echo "Failed to switch to branch '$2'."; exit 1; }
  git rebase "$1" || {
    echo "Rebase conflicts detected. Please resolve them and retry."
    git checkout -
    exit 1
  }
  echo "Branch '$1' successfully rebased onto '$2'."
}

# Parse command-line arguments
while getopts "1b:d:m:r:-:" opt; do
  case "$opt" in
    1) list_branches ;;
    b) create_branch "$OPTARG" ;;
    d) delete_branch "$OPTARG" ;;
    m)
      while [[ $# -gt 0 ]]; do
        case "$1" in
          -1)
            source_branch="$2"
            shift 2
            ;;
          -2)
            target_branch="$2"
            shift 2
            ;;
          *)
            shift
            ;;
        esac
      done
      merge_branches "$source_branch" "$target_branch"
      ;;
    r)
      while [[ $# -gt 0 ]]; do
        case "$1" in
          -1)
            base_branch="$2"
            shift 2
            ;;
          -2)
            target_branch="$2"
            shift 2
            ;;
          *)
            shift
            ;;
        esac
      done
      rebase_branches "$base_branch" "$target_branch"
      ;;
    *)
      echo "Invalid option."
      echo "Usage: $0 -1 (list branches) -b <branch_name> (create branch) -d <branch_name> (delete branch)"
      echo "       -m -1 <source_branch> -2 <target_branch> (merge branches) -r -1 <base_branch> -2 <target_branch> (rebase branches)"
      exit 1
      ;;
  esac
done
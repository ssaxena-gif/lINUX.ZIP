#!/bin/bash

# Global variable for service file
SERVICE_FILE="/tmp/services.txt"

# Register a service with alias 
register_service() {
    alias=$2
    script_path=$1

    # Check if the service alias already exists
    if grep -q "^$alias," "$SERVICE_FILE"; then
        echo "Error: Service with alias '$alias' is already registered."
    else
        echo "$alias,$script_path,stopped,low" >> "$SERVICE_FILE"
        echo "Service $alias registered."
    fi
}

# Start a service using alias
start_service() {
    alias=$1  # The service alias provided by the user.

    # Retrieve the script path associated with the alias.
    script_path=$(grep "^$alias," "$SERVICE_FILE" | cut -d',' -f2)

    # Check if the script path is empty or if the alias was not found.
    if [[ -z "$script_path" ]]; then
        echo "Error: Service alias '$alias' not found."
        return 1  # Exit the function with an error status.
    fi

    # Check if the script is executable.
    if [[ ! -x "$script_path" ]]; then
        echo "Error: Script '$script_path' is not executable."
        return 1
    fi

    # Start the service in the background.
    nohup "$script_path" &>/dev/null &  # Ignore hangup signals and redirect output.
    pid=$!  # Capture the PID of the started service.

    # Update the service status to 'running' in the service file.
    sed -i "s|^$alias,.*|$alias,$script_path,running,low,$pid|" "$SERVICE_FILE"

    # Print confirmation with the service alias and PID.
    echo "Service '$alias' started with PID $pid."

    # Wait for the process to complete.
    wait $pid

    # After the process finishes, update the service status to 'stopped'.
    sed -i "s|^$alias,.*|$alias,$script_path,stopped,low,|" "$SERVICE_FILE"

    echo "Service '$alias' has completed and stopped."
}

# Show service status using alias
status_service() {
    alias=$1
    grep "^$alias," "$SERVICE_FILE" | cut -d',' -f3
}

# Stop a service using alias
kill_service() {
    alias=$1
    pid=$(grep "^$alias," "$SERVICE_FILE" | cut -d',' -f5)

    # Check if the PID is not empty before attempting to kill
    if [[ -n "$pid" ]]; then
        kill "$pid"

        # Update the service status to stopped
        script_path=$(grep "^$alias," "$SERVICE_FILE" | cut -d',' -f2)
        sed -i "s|^$alias,.*|$alias,$script_path,stopped,low|" "$SERVICE_FILE"

        echo "Service $alias stopped."
    else
        echo "Service with alias '$alias' not found or already stopped."
    fi
}

# Change priority using alias
change_priority() {
    alias=$1
    priority=$2
    # Update the priority field for the given alias
    sed -i "s/^$alias,.*/$alias,$(grep "^$alias," "$SERVICE_FILE" | cut -d',' -f2),$(grep "^$alias," "$SERVICE_FILE" | cut -d',' -f3),$priority/" "$SERVICE_FILE"
    echo "Priority of $alias changed to $priority."
}

# List all services by alias
list_services() {
    cut -d',' -f1 "$SERVICE_FILE"
}

# Show service details using alias or all services
top_service() {
    alias=$1
    if [ "$alias" ]; then
        grep "^$alias," "$SERVICE_FILE"
    else
        cat "$SERVICE_FILE"
    fi
}

# Command handling
case "$1" in
    -o)
        case "$2" in
            register) register_service "$4" "$6" ;;
            start) start_service "$4" ;;
            status) status_service "$4" ;;
            kill) kill_service "$4" ;;
            priority) change_priority "$4" "$6" ;;
            list) list_services ;;
            top) top_service "$4" ;;
            *) echo "Invalid option" ;;
        esac
        ;;
    *) echo "Invalid operation" ;;
esac
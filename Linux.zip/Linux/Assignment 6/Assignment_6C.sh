#!/bin/bash

# Check if enough arguments are provided
if [ "$#" -lt 2 ]; then
    echo "Usage: $0 <service_name> <process_id>"
    exit 1
fi

# Command-line arguments for service name and process ID
service_name="$1"
process_id="$2"

# Example log file path, replace with the actual log file path
log_file="/tmp/services.txt"  # You can pass this as a third argument if needed

# Function to check if a service is running
is_service_running() {
    local process_id="$1"
    if ps -p "$process_id" > /dev/null; then
        return 0  # Service is running
    else
        return 1  # Service is not running
    fi
}

# Command to remove the log entry for the running process
remove_running_process_log() {
    echo "Removing log entry for service $service_name (PID: $process_id)..."
    if [ -f "$log_file" ]; then
        # Use sed to remove the line containing the process ID
        sed -i "/$process_id/d" "$log_file"
        echo "Log entry for process ID $process_id removed."
    else
        echo "Log file does not exist."
    fi
}

# Function to delete the entire log file
delete_log_file() {
    echo "Deleting the log file: $log_file"
    if [ -f "$log_file" ]; then
        rm "$log_file"  # This removes the log file completely
        echo "Log file $log_file deleted."
    else
        echo "Log file does not exist."
    fi
}

# Command to elevate the process priority
elevate_process_priority() {
    echo "Elevating priority of process with PID $process_id..."
    renice -n -10 -p "$process_id"
    echo "Priority of process $process_id elevated."
}

# Check if the service is running
if is_service_running "$process_id"; then
    echo "Service $service_name is running."

    # Run specific commands based on user input
    case "$3" in
        remove_log)
            remove_running_process_log
            ;;
        delete)
            delete_log_file
            ;;
        elevate)
            elevate_process_priority
            ;;
        *)
            echo "Usage: $0 <service_name> <process_id> <command>"
            echo "Commands: remove_log, delete, elevate"
            exit 1
            ;;
    esac
else
    echo "Service $service_name is not running. No action needed."
fi
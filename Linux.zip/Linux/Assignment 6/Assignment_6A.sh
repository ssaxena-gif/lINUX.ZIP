#!/bin/bash

# Function to list top N processes by memory or CPU
topProcess() {
    ps -eo pid,comm,%mem,%cpu --sort=-%$2 | head -n $(( $1 + 1 ))
}

# Kill the process with the least priority
killLeastPriorityProcess() {
    kill -9 $(ps -eo pid,pri --sort=+pri | awk 'NR==2 {print $1}')
}

# Get running duration of a process by name or PID
RunningDurationProcess() {
    ps -p $(pgrep -x $1 || echo $1) -o etime=
}

# List orphan processes
listOrphanProcess() {
    ps -eo pid,ppid,comm | awk '$2 == 1 {print $0}'
}

# List zombie processes
listZoombieProcess() {
    ps aux | awk '$8 == "Z"'
}

# Kill a process by name or PID
killProcess() {
    kill -9 $(pgrep -x $1 || echo $1)
}

# List processes waiting for resources
ListWaitingProcess() {
    ps -eo pid,comm,state | grep ' D '
}

# Dispatch function calls
case $1 in
    topProcess) topProcess $2 $3 ;;
    killLeastPriorityProcess) killLeastPriorityProcess ;;
    RunningDurationProcess) RunningDurationProcess $2 ;;
    listOrphanProcess) listOrphanProcess ;;
    listZoombieProcess) listZoombieProcess ;;
    killProcess) killProcess $2 ;;
    ListWaitingProcess) ListWaitingProcess ;;
    *) echo "Invalid option" ;;
esac
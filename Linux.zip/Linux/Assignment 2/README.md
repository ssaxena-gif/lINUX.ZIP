ASSIGNMENT 2.1
-------------------------------------------------------------
In this Assignment  we will cover some basic command of linux
Create user named neha, vipul and abhishek
create group named linux
Create group named sigma
Change neha and abhishek primary group to sigma
change neha and abhishek secondary group to linux
create group named alpha
create user nkhil and priyashi and add them to linux and aplha group with single command
Change all user home directory permission to
A user should have read,write, execute access to home directory
All the users of same team should have read and excute access to home directory of fellow team members.
others should have only execute permission to user’s home directory
create these directory structure for all user
home directory of user
team
linux
change permission for team directory only team members have full access
change permission for linux directory only linux trainer have full access
check if alpha team user can access sigma team directory.
check vipul user can access sigma or
change vipul user shell to make it service user.
force abhishek user to change its password on next login.
change nikhil user password.
list all user and group you have created
check which shell is added to neha user as default.
check the deafult permission of file and directory and how to change it
now delete vipul user.
delete linux group.


ASSIGNMENT 2.2
-------------------------------------------------------------
This is your new assignment
iUserManager utility
Add NinjaTeam (Simulate Group) ex: team1
Add a User (Simulate) under a team ex: Nitish added to team1
Ensure below constraints are met:
A user should have read,write, execute access to home directory
All the users of same team should have read and excute access to home directory of fellow team members.
others should have only execute permission to user's home directory
In home directory of every user there should be 2 shared directories
team: Same team members will have full access
ninja: All ninja's will have full access
i.e
./UserManager.sh addTeam amigo
./UserManager.sh addTeam unixkings
./UserManager.sh addUser Rakesh amigo
./UserManager.sh addUser Sandeep unixkings
Resultant Structure
/home
Rakesh
team
ninja
Sandeep
team
ninja
Additional Features
change user Shell
change user password
Delete user
Delete Group
list user or Team
i.e
./UserManager.sh delTeam amigo
./UserManager.sh delUser Rakesh
./UserManager.sh changePasswd Rakesh
./UserManager.sh changeShell Rakehs /bin/bash
./UserManager.sh ls User
./UserManager.sh ls Team
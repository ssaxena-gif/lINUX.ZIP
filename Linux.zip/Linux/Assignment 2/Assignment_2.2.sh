#!/bin/bash

# variables
action=$1
name=$2
group=$3

# Create group
case "$action" in
  addTeam)
   sudo groupadd "$name"
    echo "group created $name"
    ;;
# Create user
  addUser)
    sudo useradd -m "$name" -G $group
    echo "user created $name and added in group $group"
    sudo chmod 751 /home/$name
    sudo mkdir /home/$name/ninja
    echo "shared directory1 created in $name"
    sudo mkdir /home/$name/team
    echo "shared directory2 created in $name"
    sudo chown -R "$name:$group" "/home/$name/team"
    sudo chown -R "$name:$group" "/home/$name/ninja"
    sudo chmod 770 "/home/$name/ninja"
    sudo chmod 770 "/home/$name/team"
    ;;
# Change shell
  changeShell)
    sudo  chsh -s /bin/bash "$name"
    echo "change $name shell"
    ;;
# Change password
  changePasswd)
    sudo passwd "$name"
    echo "change $name password"
    ;;
# Delete user
  delUser)
    sudo userdel "$name"
    echo "delete user $name"
    ;;
# Delete Group
  delTeam)
    sudo groupdel "$name"
    echo "delete group $name"
    ;;
# list user or Team
   ls)
        if [[ "$name" == "User" ]]; then
            cat /etc/passwd
        elif [[ "$name" == "Team" ]]; then
            cat /etc/group
        else
            echo "No list found"
        fi
        ;;
    *)
        echo "check error"
        ;;
esac

Assignment 3 Part A
Please find your assignment for today
Create a shell script to generate a star, it will take 2 arguments size & type
./drawStar.sh 5 t1
    *
   **
  ***
 ****
*****
./drawStar.sh 5 t2
*
**
***
****
*****
./drawStar.sh 5 t3
    *
   ***
  *****
 *******
*********
./drawStar.sh 5 t4
*****
****
***
**
*
./drawStar.sh 5 t5
*****
 ****
  ***
   **
    *
./drawStar.sh 5 t6
*********
 *******
  *****
   ***
    *
./drawStar.sh 5 t7
    *
   ***
  *****
 *******
*********
 *******
  *****
   ***
    *


Assignment 3 Part B
-------------------------------------------------------
Create a shell script that will take take a number and print below output depending on the conditions
tom -> If number is divisible by 3
cat -> If number is divisible by 5
tomcat -> If number is divisible by 15
i.e
./printTomcat.sh 7
./printTomcat.sh 6
tom
./printTomcat.sh 10
cat
./printTomcat.sh 30
tomcat

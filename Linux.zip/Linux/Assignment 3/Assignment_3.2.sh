#!/bin/bash

# Get the number from the argument
num=$1

# Check the conditions
if [ $(($num % 15)) -eq 0 ]; then
    echo "tomcat"
elif [ $(($num % 3)) -eq 0 ]; then
    echo "tom"
elif [ $(($num % 5)) -eq 0 ]; then
    echo "cat"
else
    echo "error"
fi
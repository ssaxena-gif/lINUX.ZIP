
#!/bin/bash

# Get size and type from arguments
size=$1
type=$2

# Loop to generate patterns
if [ "$type" == "t1" ]; then
  for ((i=1; i<=size; i++)); do
    printf "%*s" $(( size - i )) ""
    for ((j=1; j<=i; j++)); do
      printf "*"
    done
    echo
  done
fi

if [ "$type" == "t2" ]; then
  for ((i=1; i<=size; i++)); do
    for ((j=1; j<=i; j++)); do
      printf "*"
    done
    echo
  done
fi

if [ "$type" == "t3" ]; then
  for ((i=1; i<=size; i++)); do
    printf "%*s" $(( size - i )) ""
    for ((j=1; j<=(2*i-1); j++)); do
      printf "*"
    done
    echo
  done
fi

if [ "$type" == "t4" ]; then
  for ((i=size; i>=1; i--)); do
    for ((j=1; j<=i; j++)); do
      printf "*"
    done
    echo
  done
fi

if [ "$type" == "t5" ]; then
  for ((i=1; i<=size; i++)); do
    printf "%*s" $i ""
    for ((j=1; j<=size-i+1; j++)); do
      printf "*"
    done
    echo
  done
fi

if [ "$type" == "t6" ]; then
  for ((i=size; i>=1; i--)); do
    printf "%*s" $((size - i)) ""
    for ((j=1; j<=2*i-1; j++)); do
      printf "*"
    done
    echo
  done
fi

if [ "$type" == "t7" ]; then
  # Upper diamond
  for ((i=1; i<=size; i++)); do
    printf "%*s" $(( size - i )) ""
    for ((j=1; j<=(2*i-1); j++)); do
      printf "*"
    done
    echo
  done
  # Lower diamond
  for ((i=size-1; i>=1; i--)); do
    printf "%*s" $(( size - i )) ""
    for ((j=1; j<=(2*i-1); j++)); do
      printf "*"
    done
    echo
  done
fi


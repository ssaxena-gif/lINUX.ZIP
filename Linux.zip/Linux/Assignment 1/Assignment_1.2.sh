#!/bin/bash

action=$1
path=$2
dirnm=$3
content=$4
content2=$5
fpath="$path/$dirnm"

#Create directory
if [ "$action" == "addDir" ]; then
    if [ ! -d "$path/$dirnm" ]; then
        mkdir -p "$path/$dirnm"
        echo "Directory is created '$path/$dirnm'."
    fi

#Delete directory
elif [ "$action" == "deleteDir" ]; then
    if [ -d "$path/$dirnm" ]; then
        rm -r "$path/$dirnm"
        echo "Directory is deleted '$path/$dirnm'."
    fi

#List all contents directory
elif [ "$action" == "listAll" ]; then
    if [ -d "$path" ]; then
        ls -la "$path"
    fi

#List only files directory
elif [ "$action" == "listFiles" ]; then
    if [ -d "$path" ]; then
        find "$path" -type f
    fi

#List only directories directory
elif [ "$action" == "listDirs" ]; then
    if [ -d "$path" ]; then
        find "$path" -type d
    fi

#Create file
elif [ "$action" == "addFile" ]; then
    if [ ! -f "$fpath" ]; then
        touch "$fpath"
    else
        echo "$content" > "$fpath"
        echo "File is created '$fpath'."
    fi

#Create file with content
elif [ "$action" == "addFileC" ]; then
    if [ ! -f "$fpath" ]; then
        echo "$content" > "$fpath"
        echo "File is created with initial content '$fpath'."
    fi

#Add content in file
elif [ "$action" == "addContentToFile" ]; then
    if [ -f "$fpath" ]; then
        echo "$content" >> "$fpath"
        echo "Content added in file '$fpath'."
    fi

#Add content in file(beginning)
elif [ "$action" == "addContentToFileBegining" ]; then
    if [ -f "$fpath" ]; then
        echo -e "$content\n$(cat $fpath)"  > "$fpath"
        echo "Content added in file(beginning) '$fpath'."
    fi

#Show the first lines
elif [ "$action" == "showFileBeginingContent" ]; then
    if [ -f "$fpath" ]; then
        head -n "$content" "$fpath"
    fi

#Show the last lines
elif [ "$action" == "showFileEndContent" ]; then
    if [ -f "$fpath" ]; then
        tail -n "$content" "$fpath"
    fi

#Show the specific line
elif [ "$action" == "showFileContentAtLine" ]; then
    if [ -f "$fpath" ]; then
        awk "NR==$content" "$fpath"
    fi

#Show the specific line range
elif [ "$action" == "showFileContentForLineRange" ]; then
    if [ -f "$fpath" ]; then
        awk "NR>=$content && NR<=$content2" "$fpath"
    fi

#Move file
elif [ "$action" == "moveFile" ]; then
    if [ -f "$path" ]; then
        mv "$path" "$dirnm"
        echo "File moved from '$path' to '$dirnm'."
    fi

#Copy file
elif [ "$action" == "copyFile" ]; then
    if [ -f "$path" ]; then
        cp "$path" "$dirnm"
        echo "File copied from '$path' to '$dirnm'."
    fi

#Clear file content
elif [ "$action" == "clearFileContent" ]; then
    if [ -f "$fpath" ]; then
        > "$fpath"
        echo "File content cleared '$fpath'."
    fi

#Delete a file
elif [ "$action" == "deleteFile" ]; then
    if [ -f "$fpath" ]; then
        rm "$fpath"
        echo "File '$fpath' deleted successfully."
    fi


else
    echo "Invalid command."
fi
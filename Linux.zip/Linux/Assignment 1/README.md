ASSIGNMENT 1.1
In this Assignment  we will cover some basic command of linux

First check your current working directory
Now create directory with name "linux" in your current directory.
Then create a another directory  with name "Assignment-01" inside your "linux" directory  .
Now create one more directory inside "/tmp" with name "dir1" without changing your present directory.
At last create two more directories having below tree structure .It should create a below structure via single command only .
```
/tmp

dir1
dir2
dir3
        
```  

Find a command  that will delete a "dir3" that you have created before.
Now create a empty file with your "firt-name"  in /tmp directory.
After creating a empty file , add "This is my first line " into a file without using any editor.
Now add  one more line "this is a additional content " into a same file .Make sure it will not overwrite the previous line of the file.
Then  create new  file with your  "last-name" along with some content like "last-name is my last name".Do not use any editor
Now add "this is line at the  beginning" into "last-name" file  in such a manner that it will add the line at beginning of the file.Do not use any editor.
Then add some more 8-10  lines to the same file .
Now find a command that will show:
top 5 lines of the file.
bottom 2 lines of the  file.
only 6th line  of the file.
3-8 lines of the file .
Find a command that will list  below things of /tmp directory
list all content(including hidden files)
list only files
list only directories
Now copy the "last-name" into the /tmp/dir2 with same name.
Then again copy the "last-name" into the /tmp/dir2, this time with different name i.e "last-name".copy
Now change the name of the "first-name" file  to some other name at same location .
Find a command that will  move the "last-name" file  to /tmp/dir1
find a command that will clear the content of /tmp/dir2/"last-name".copy .Make sure it will not even contain  empty line .
Now delete the same file i.e /tmp/dir2/last-name.copy
Note : Do not use sed command in this assignment.




ASSIGNMENT 1.2 : Basic Linux Commands
------------------------------------------------------------
Create a utility(FileManager.sh) that will be able to
Create a Directory
Delete a Directory
List Content of a Directory
Only listfiles in a Directory
Only listDirs in a Directory
listAll(files and directory)
For example
./FileManager.sh addDir /tmp dir1
./FileManager.sh addDir /tmp dir2
./FileManager.sh addDir /tmp dir3
./FileManager.sh listFiles /tmp
./FileManager.sh listDirs /tmp
./FileManager.sh listAll /tmp
./FileManager.sh deleteDir /tmp dir3
Update FileManager to process Files as well
Create a file
Add content to file
Add conent at the begining of the file
Show top n lines of a file
Show last n lines of a file
Show contents of a specific line number
Show conteint of a specfific line number range
Move/Copy file from one location to another
Delete file
For example
./FileManager.sh addFile /tmp/dir1 file1.txt
./FileManager.sh addFile /tmp/dir1 file1.txt "Initial Content"
./FileManager.sh addContentToFile /tmp/dir1 file1.txt "Additional Content"
./FileManager.sh addContentToFileBegining /tmp/dir1 file1.txt "Additional Content"
./FileManager.sh showFileBeginingContent /tmp/dir1 file1.txt 5
./FileManager.sh showFileEndContent /tmp/dir1 file1.txt 5
./FileManager.sh showFileContentAtLine /tmp/dir1 file1.txt 10
./FileManager.sh showFileContentForLineRange /tmp/dir1 file1.txt 5 10
./FileManager.sh moveFile /tmp/dir1/file1.txt /tmp/dir1/file2.txt
./FileManager.sh moveFile /tmp/dir1/file2.txt /tmp/dir2/
./FileManager.sh copyFile /tmp/dir2/file2.txt /tmp/dir1/
./FileManager.sh copyFile /tmp/dir1/file2.txt /tmp/dir1/file3.txt
./FileManager.sh clearFileContent /tmp/dir1 file3.txt
./FileManager.sh deleteFile /tmp/dir1 file2.txt
Note: Do not use sed command.Try to do this assignment only with linux basic commands
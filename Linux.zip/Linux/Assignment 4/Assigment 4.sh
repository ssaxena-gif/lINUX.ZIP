#!/bin/bash

# File to store SSH connection details in config style
configfile="/home/ubuntu/.ssh/config"

# Function to add an SSH connection in config format
add_ssh_connection() {
    local name=$1
    local host=$2
    local user=$3
    local port=${4:-22}  # Default port to 22 if not provided

    # Check if the connection name already exists
    if grep -q "^Host $name" "$configfile"; then
        echo "[ERROR]: Connection with name '$name' already exists."
    else
        # Add connection details to the config file in the required format
        {
            echo "Host $name"
            echo "    HostName $host"
            echo "    User $user"
            echo "    Port $port"
            echo ""
        } >> "$configfile"
        echo "[INFO]: Added SSH connection: $name"
    fi
}

# Function to remove an SSH connection
remove_ssh_connection() {
    local name="$1"

    # Check if config file exists and connection exists
    [[ ! -f "$configfile" ]] && { echo "[ERROR]: Config file not found."; return 1; }
    ! grep -q "^Host $name$" "$configfile" && { echo "[ERROR]: Connection '$name' does not exist."; return 1; }

    # Remove connection
    sed -i "/^Host $name$/,/^$/d" "$configfile" && echo "[INFO]: SSH connection '$name' removed." || echo "[ERROR]: Failed to remove '$name'."
}

# Function to list SSH connections
list_ssh_connections() {
    if [[ "$1" == "-d" ]]; then
        grep -A 3 "^Host" "$configfile"
    else
        grep "^Host" "$configfile" | awk '{print $2}'
    fi
}

# Function to connect to a server
connect_to_server() {
    local name="$1"

    # Check if the server exists in the config and extract details
    if grep -q "^Host $name" "$configfile"; then
        host=$(grep -A 1 "^Host $name" "$configfile" | awk '/HostName/ {print $2}')
        user=$(grep -A 2 "^Host $name" "$configfile" | awk '/User/ {print $2}')
        port=$(grep -A 3 "^Host $name" "$configfile" | awk '/Port/ {print $2}')
        
        # Default to port 22 if not specified
        port=${port:-22}

        # Connect using SSH
        echo "Connecting to $name ($host) on port $port as $user..."
        ssh "$user@$host" -p "$port"
    else
        echo "[ERROR]: Server '$name' information is not available. Please add the server first."
    fi
}
# Function to update an SSH connection
update_ssh_connection() {
    local name="$1" host="$2" user="$3" port="${4:-22}"

    # Check if the connection exists using the list function
    if ! list_ssh_connections | grep -q "^$name$"; then
        echo "[ERROR]: Connection '$name' not found."
        return 1
    fi

    # Remove the old connection
    remove_ssh_connection "$name"

    # Add the new (updated) connection
    add_ssh_connection "$name" "$host" "$user" "$port"
}

# Main logic for handling options
case $1 in
    -a)  # Add a connection
        shift
        while getopts "n:h:u:p:" opt; do
            case "$opt" in
                n) name="$OPTARG" ;;
                h) host="$OPTARG" ;;
                u) user="$OPTARG" ;;
                p) port="$OPTARG" ;;
            esac
        done
        [[ -z "$name" || -z "$host" || -z "$user" ]] && { echo "[ERROR]: Missing required parameters."; exit 1; }
        add_ssh_connection "$name" "$host" "$user" "$port"
        ;;

    ls)  # List all connections
        list_ssh_connections "$2"
        ;;

    -u)  # Update a connection
        shift
        while getopts "n:h:u:p:" opt; do
            case "$opt" in
                n) name="$OPTARG" ;;
                h) host="$OPTARG" ;;
                u) user="$OPTARG" ;;
                p) port="$OPTARG" ;;
            esac
        done
        [[ -z "$name" || -z "$host" || -z "$user" ]] && { echo "[ERROR]: Missing required parameters."; exit 1; }
        update_ssh_connection "$name" "$host" "$user" "$port"
        ;;

    rm)  # Remove a connection
        [[ -z "$2" ]] && { echo "[ERROR]: Missing connection name to remove."; exit 1; }
        remove_ssh_connection "$2"
        ;;

    *)  # Connect to a server
        connect_to_server "$1"
        ;;
esac
